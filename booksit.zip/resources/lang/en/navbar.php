<?php

return array (
  'home' => 'Home',
  'about' => 'About Us',
  'services' => 'Services',
  'service-detail' => 'Service Detail',
  'portfolios' => 'Awords',
  'portfolio-detail' => 'Aword Detail',
  'pricing' => 'Text Books',
  'blog' => 'Blog',
  'blog-detail' => 'Blog Detail',
  'faqs' => 'FAQs',
  'contact' => 'Contact Us',
  'get_quote' => 'Order',
  'error' => 'Error 404',
  'payment_feedback' => 'Payment Feedback',
);
