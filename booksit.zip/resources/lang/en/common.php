<?php

return array (
  'read_more' => 'Read More',
  'view_more' => 'View More',
  'get_start' => 'Get Start',
  'contact_us' => 'Contact Us',
  'go_home' => 'Go Home',
  'category' => 'Category',
  'categories' => 'Categories',
  'all' => 'All',
  'currency' => '$',
  'footer_links' => 'Useful Links',
  'recent_posts' => 'Recent Posts',
);
