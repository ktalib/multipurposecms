
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">
    
    <!-- start page title -->
    <!-- Include page breadcrumb -->
    <?php echo $__env->make('admin.inc.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end page title --> 


    <div class="row">
        <div class="col-12">
            <a href="<?php echo e(route($route.'.index')); ?>" class="btn btn-info"><?php echo e(__('dashboard.back')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title"><?php echo e(__('dashboard.view')); ?> <?php echo e($title); ?></h4>
                </div>
                <div class="card-body">

                    <!-- Details View Start -->
                    <h4><span class="text-highlight"><?php echo e(__('dashboard.title')); ?>:</span> <?php echo e($row->title); ?></h4>
                    <p><span class="text-highlight"><?php echo e(__('dashboard.category')); ?>:</span> 
                        <?php $__currentLoopData = $row->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge badge-primary"><?php echo e($category->title); ?></span> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <hr/>

                    <?php if(!empty($row->video_id)): ?>
                    <p><span class="text-highlight"><?php echo e(__('dashboard.youtube_video')); ?>:</span></p>
                    <div class="embed-responsive embed-responsive-16by9">
                      <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($row->video_id); ?>?rel=0" allowfullscreen></iframe>
                    </div>
                    <br/>
                    <?php endif; ?>

                    <?php if(is_file('uploads/'.$path.'/'.$row->image_path)): ?>
                    <p><span class="text-highlight"><?php echo e(__('dashboard.thumbnail')); ?>:</span></p>
                    <img src="<?php echo e(asset('uploads/'.$path.'/'.$row->image_path)); ?>" class="img-fluid" alt="Portfolio">
                    <?php endif; ?>

                    <hr/>
                    <p><span class="text-highlight"><?php echo e(__('dashboard.description')); ?>:</span> <?php echo $row->description; ?></p>

                    <?php if(!empty($row->link)): ?>
                    <hr/>
                    <p><span class="badge badge-primary"><?php echo e(__('dashboard.web_link')); ?>:</span> <a href="<?php echo e($row->link); ?>" target="_blank"><?php echo e($row->link); ?></a></p>
                    <?php endif; ?>
                    <hr/>
                    <p><span class="text-highlight"><?php echo e(__('dashboard.status')); ?>:</span> 
                    <?php if( $row->status == 1 ): ?>
                    <span class="badge badge-success badge-pill"><?php echo e(__('dashboard.active')); ?></span>
                    <?php else: ?>
                    <span class="badge badge-danger badge-pill"><?php echo e(__('dashboard.inactive')); ?></span>
                    <?php endif; ?>
                    </p>
                    <!-- Details View End -->
                </div>
            </div>
        </div><!-- end col-->
    </div>
    <!-- end row-->

    
</div> <!-- container -->
<!-- End Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\multipurposebusiness\resources\views/admin/portfolio/show.blade.php ENDPATH**/ ?>