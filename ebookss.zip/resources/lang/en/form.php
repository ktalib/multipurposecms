<?php

return array (
  'your_name' => 'Your Name *',
  'phone_no' => 'Phone No *',
  'email_address' => 'Email Address *',
  'address' => 'Address *',
  'city' => 'City *',
  'company' => 'Company (Optional)',
  'prefer_contact' => 'What do you prefer for contact? *',
  'phone' => 'Phone',
  'email' => 'Email',
  'services' => 'Publications (You can choose multiple)',
  'your_massage' => 'Write Your Order Detail Here... *',
  'upload_file' => 'Upload Proof (Optional)',
  'submit' => 'Submit Now',
);
