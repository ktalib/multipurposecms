
<?php $__env->startSection('title', __('navbar.error')); ?>
<?php $__env->startSection('content'); ?>

    <!--Page Title-->
    <section class="page-title">
        <div class="container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <h1><?php echo e(__('navbar.error')); ?></h1>
                </div>
                <div class="bread-crumb">
                    <ul>
                        <li><?php echo e(__('navbar.error')); ?></li>
                        <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('navbar.home')); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--End Page Title-->

    <?php
        $section_error = \App\Models\Section::section('error');
    ?>
    <?php if(isset($section_error)): ?>
    <!--Error Section-->     
    <section class="error-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="inner-container text-center">
                        <div class="image-box">
                            <figure><img src="<?php echo e(asset('web/images/resource/error-img.png')); ?>" alt="Error"></figure>
                        </div>
                        <div class="text-box">
                            <h1><?php echo e($section_error->title); ?></h1>
                            <div class="text"><?php echo $section_error->description; ?></div>
                            <a href="<?php echo e(route('home')); ?>" class="thm-btn btn-style-four"><?php echo e(__('common.go_home')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Error Section-->
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\multipurposebusiness\resources\views/errors/404.blade.php ENDPATH**/ ?>